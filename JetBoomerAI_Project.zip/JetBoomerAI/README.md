# JetBoomer AI Scalper — Android + MT5 + API

This is a complete starter project for a phone-controlled MetaTrader 5 scalping system.

## Architecture

Huawei Y72 (Android APK) → HTTPS API → MT5 Expert Advisor → Deriv MT5 / Weltrade MT5

The Android app is a control/monitoring panel. The MT5 Expert Advisor is the component that actually reads market data and sends orders. MetaTrader's official documentation confirms that EAs are the automated-trading component and that VPS hosting can keep them running 24/7. See the official docs linked in `INSTALL.md`.

## Included

- Android control app source
- FastAPI connection layer
- MQL5 Expert Advisor
- Market scanner / signal scoring
- 3/5 simultaneous trade controls
- TP/SL, spread filter, cooldown
- Daily profit target and daily loss limit
- Emergency stop / close-all command
- Demo-first configuration
- GitHub Actions workflow to build the APK without Android Studio on the user's phone

## Important

This project does **not** guarantee profit. A $5 account is extremely small and broker minimum lot sizes, margin, spread, slippage and losses can prevent the requested profit pattern. The default configuration is conservative and the live-trading flag is disabled until explicitly changed.

Never put your broker password or withdrawal credentials in the Android app or source repository.
