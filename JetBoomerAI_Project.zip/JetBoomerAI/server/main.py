from datetime import datetime, timezone, date
from typing import Dict, Any
import os
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

API_KEY = os.getenv("JETBOOMER_API_KEY", "CHANGE-ME")
app = FastAPI(title="JetBoomer AI Scalper API", version="1.0.0")

state: Dict[str, Any] = {
    "running": False,
    "close_all": False,
    "daily_profit_target": 20.0,
    "daily_loss_limit": 1.0,
    "max_open_trades": 3,
    "risk_percent": 0.5,
    "daily_profit": 0.0,
    "equity": 0.0,
    "balance": 0.0,
    "open_trades": 0,
    "last_signal": "WAIT",
    "last_heartbeat": None,
    "symbol": "",
    "features": {},
}

class Heartbeat(BaseModel):
    balance: float = 0
    equity: float = 0
    daily_profit: float = 0
    open_trades: int = 0
    symbol: str = ""
    signal: str = "WAIT"
    features: Dict[str, float] = Field(default_factory=dict)

class Settings(BaseModel):
    daily_profit_target: float = Field(20.0, gt=0)
    daily_loss_limit: float = Field(1.0, gt=0)
    max_open_trades: int = Field(3, ge=1, le=5)
    risk_percent: float = Field(0.5, gt=0, le=2)


def auth(x_api_key: str | None):
    if not x_api_key or x_api_key != API_KEY:
        raise HTTPException(401, "Invalid API key")

@app.get("/health")
def health():
    return {"ok": True, "service": "jetboomer", "time": datetime.now(timezone.utc).isoformat()}

@app.get("/status")
def status(x_api_key: str | None = Header(default=None)):
    auth(x_api_key)
    return state

@app.post("/heartbeat")
def heartbeat(hb: Heartbeat, x_api_key: str | None = Header(default=None)):
    auth(x_api_key)
    state.update({
        "balance": hb.balance,
        "equity": hb.equity,
        "daily_profit": hb.daily_profit,
        "open_trades": hb.open_trades,
        "symbol": hb.symbol,
        "last_signal": hb.signal,
        "features": hb.features,
        "last_heartbeat": datetime.now(timezone.utc).isoformat(),
    })
    # Hard stop conditions are server-side as a second layer of protection.
    if hb.daily_profit >= state["daily_profit_target"]:
        state["running"] = False
    if hb.daily_profit <= -abs(state["daily_loss_limit"]):
        state["running"] = False
    close = state["close_all"]
    state["close_all"] = False
    return {"running": state["running"], "close_all": close, "settings": {
        "daily_profit_target": state["daily_profit_target"],
        "daily_loss_limit": state["daily_loss_limit"],
        "max_open_trades": state["max_open_trades"],
        "risk_percent": state["risk_percent"],
    }}

@app.post("/start")
def start(x_api_key: str | None = Header(default=None)):
    auth(x_api_key)
    state["running"] = True
    return {"running": True}

@app.post("/stop")
def stop(x_api_key: str | None = Header(default=None)):
    auth(x_api_key)
    state["running"] = False
    return {"running": False}

@app.post("/close-all")
def close_all(x_api_key: str | None = Header(default=None)):
    auth(x_api_key)
    state["running"] = False
    state["close_all"] = True
    return {"running": False, "close_all": True}

@app.post("/settings")
def settings(s: Settings, x_api_key: str | None = Header(default=None)):
    auth(x_api_key)
    state["daily_profit_target"] = s.daily_profit_target
    state["daily_loss_limit"] = s.daily_loss_limit
    state["max_open_trades"] = s.max_open_trades
    state["risk_percent"] = s.risk_percent
    return state
