#property strict
#property version   "1.00"
#property description "JetBoomer AI Scalper - phone controlled MT5 EA"

#include <Trade/Trade.mqh>
CTrade trade;

input string ApiBaseUrl = "https://YOUR-DOMAIN.example";
input string ApiKey = "CHANGE-ME";
input bool EnableLiveTrading = false;
input int MaxOpenTrades = 3;
input double RiskPercentPerTrade = 0.5;
input double DailyProfitTarget = 20.0;
input double DailyLossLimit = 1.0;
input double TakeProfitUSD = 0.80;
input double StopLossUSD = 0.80;
input int FastEMA = 9;
input int SlowEMA = 21;
input int RSIPeriod = 14;
input double BuyRSIMin = 52.0;
input double SellRSIMax = 48.0;
input int MaxSpreadPoints = 30;
input int CooldownSeconds = 60;
input ulong Magic = 26091601;

bool localRunning = false;
datetime lastTradeTime = 0;
datetime dayStart = 0;
double dayStartBalance = 0;
int hFast=INVALID_HANDLE, hSlow=INVALID_HANDLE, hRSI=INVALID_HANDLE;

bool GetValue(int handle, int shift, double &value){
   double b[1];
   if(handle==INVALID_HANDLE) return false;
   if(CopyBuffer(handle,0,shift,1,b)!=1) return false;
   value=b[0]; return true;
}

void ReleaseIndicators(){
   if(hFast!=INVALID_HANDLE) IndicatorRelease(hFast);
   if(hSlow!=INVALID_HANDLE) IndicatorRelease(hSlow);
   if(hRSI!=INVALID_HANDLE) IndicatorRelease(hRSI);
}

string JsonEscape(string s){ StringReplace(s,"\\","\\\\"); StringReplace(s,"\"","\\\""); return s; }

bool HttpPost(string endpoint, string body, string &response){
   string url = ApiBaseUrl + endpoint;
   char data[]; StringToCharArray(body,data,0,WHOLE_ARRAY,CP_UTF8);
   char result[]; string headers = "Content-Type: application/json\r\nX-API-Key: " + ApiKey + "\r\n";
   string result_headers;
   ResetLastError();
   int code = WebRequest("POST",url,headers,8000,data,result,result_headers);
   if(code < 200 || code >= 300){ Print("HTTP POST failed: ",code," err=",GetLastError()); return false; }
   response = CharArrayToString(result,0,-1,CP_UTF8); return true;
}

bool HttpGet(string endpoint, string &response){
   string url = ApiBaseUrl + endpoint; char data[]; char result[]; string result_headers;
   string headers = "X-API-Key: " + ApiKey + "\r\n";
   ResetLastError(); int code=WebRequest("GET",url,headers,8000,data,result,result_headers);
   if(code < 200 || code >= 300){ Print("HTTP GET failed: ",code," err=",GetLastError()); return false; }
   response=CharArrayToString(result,0,-1,CP_UTF8); return true;
}

int CountMine(){
   int n=0;
   for(int i=PositionsTotal()-1;i>=0;i--){ ulong t=PositionGetTicket(i); if(t>0 && PositionSelectByTicket(t)) if((ulong)PositionGetInteger(POSITION_MAGIC)==Magic) n++; }
   return n;
}

double DailyProfit(){ return AccountInfoDouble(ACCOUNT_EQUITY)-dayStartBalance; }

bool RiskAllows(){
   if(DailyProfit() >= DailyProfitTarget) return false;
   if(DailyProfit() <= -MathAbs(DailyLossLimit)) return false;
   if(CountMine() >= MaxOpenTrades) return false;
   if((TimeCurrent()-lastTradeTime) < CooldownSeconds) return false;
   long spread=(long)SymbolInfoInteger(_Symbol,SYMBOL_SPREAD); if(spread>MaxSpreadPoints) return false;
   return true;
}

int Signal(){
   double emaFast, emaSlow, rsi;
   if(!GetValue(hFast,0,emaFast) || !GetValue(hSlow,0,emaSlow) || !GetValue(hRSI,0,rsi)) return 0;
   double close=iClose(_Symbol,PERIOD_M1,0);
   if(emaFast>emaSlow && close>emaFast && rsi>=BuyRSIMin) return 1;
   if(emaFast<emaSlow && close<emaFast && rsi<=SellRSIMax) return -1;
   return 0;
}

double LotsFromRisk(double stopPoints){
   double riskMoney=AccountInfoDouble(ACCOUNT_BALANCE)*(RiskPercentPerTrade/100.0);
   double tickValue=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE);
   double tickSize=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   if(tickValue<=0 || tickSize<=0 || stopPoints<=0) return SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double moneyPerPointPerLot=tickValue*(SymbolInfoDouble(_Symbol,SYMBOL_POINT)/tickSize);
   if(moneyPerPointPerLot<=0) return SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double lots=riskMoney/(stopPoints*moneyPerPointPerLot);
   double minLot=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN), maxLot=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX), step=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   lots=MathMax(minLot,MathMin(maxLot,lots));
   return MathFloor(lots/step)*step;
}

void CloseMine(){
   for(int i=PositionsTotal()-1;i>=0;i--){ ulong t=PositionGetTicket(i); if(t>0 && PositionSelectByTicket(t) && (ulong)PositionGetInteger(POSITION_MAGIC)==Magic) trade.PositionClose(t); }
}

void SendHeartbeat(int sig){
   string response;
   double bal=AccountInfoDouble(ACCOUNT_BALANCE), eq=AccountInfoDouble(ACCOUNT_EQUITY), dp=DailyProfit();
   double emaF=0, emaS=0, rsi=0; GetValue(hFast,0,emaF); GetValue(hSlow,0,emaS); GetValue(hRSI,0,rsi);
   string s=(sig>0?"BUY":sig<0?"SELL":"WAIT");
   string body=StringFormat("{\"balance\":%.2f,\"equity\":%.2f,\"daily_profit\":%.2f,\"open_trades\":%d,\"symbol\":\"%s\",\"signal\":\"%s\",\"features\":{\"ema_fast\":%.5f,\"ema_slow\":%.5f,\"rsi\":%.2f}}",bal,eq,dp,CountMine(),JsonEscape(_Symbol),s,emaF,emaS,rsi);
   HttpPost("/heartbeat",body,response);
   // Simple command parsing; API response contains running/close_all booleans.
   if(StringFind(response,"\"close_all\":true")>=0) CloseMine();
   if(StringFind(response,"\"running\":true")>=0) localRunning=true;
   if(StringFind(response,"\"running\":false")>=0) localRunning=false;
}

void TryTrade(){
   if(!EnableLiveTrading || !localRunning || !RiskAllows()) return;
   int sig=Signal(); if(sig==0) return;
   double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   double tickValue=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE);
   double tickSize=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   if(point<=0 || tickValue<=0 || tickSize<=0) return;
   // Start with a broker-safe distance. The USD inputs are used as target labels;
   // actual cash result depends on symbol contract specifications and execution.
   double slPoints=MathMax(50.0,(StopLossUSD/tickValue)*(tickSize/point));
   double tpPoints=MathMax(50.0,(TakeProfitUSD/tickValue)*(tickSize/point));
   double lots=LotsFromRisk(slPoints); if(lots<=0) return;
   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK), bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   trade.SetExpertMagicNumber(Magic);
   bool ok=false;
   if(sig>0){ double sl=ask-slPoints*point,tp=ask+tpPoints*point; ok=trade.Buy(lots,_Symbol,ask,sl,tp,"JetBoomer BUY"); }
   else { double sl=bid+slPoints*point,tp=bid-tpPoints*point; ok=trade.Sell(lots,_Symbol,bid,sl,tp,"JetBoomer SELL"); }
   if(ok) lastTradeTime=TimeCurrent();
}

int OnInit(){
   dayStart=StringToTime(TimeToString(TimeCurrent(),TIME_DATE));
   dayStartBalance=AccountInfoDouble(ACCOUNT_BALANCE);
   hFast=iMA(_Symbol,PERIOD_M1,FastEMA,0,MODE_EMA,PRICE_CLOSE);
   hSlow=iMA(_Symbol,PERIOD_M1,SlowEMA,0,MODE_EMA,PRICE_CLOSE);
   hRSI=iRSI(_Symbol,PERIOD_M1,RSIPeriod,PRICE_CLOSE);
   if(hFast==INVALID_HANDLE || hSlow==INVALID_HANDLE || hRSI==INVALID_HANDLE){ Print("Indicator initialization failed"); ReleaseIndicators(); return INIT_FAILED; }
   trade.SetExpertMagicNumber(Magic);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason){ ReleaseIndicators(); }

void OnTick(){
   if(TimeCurrent()-dayStart>=86400){ dayStart=StringToTime(TimeToString(TimeCurrent(),TIME_DATE)); dayStartBalance=AccountInfoDouble(ACCOUNT_BALANCE); }
   static datetime lastBeat=0; int sig=Signal();
   if(TimeCurrent()-lastBeat>=5){ SendHeartbeat(sig); lastBeat=TimeCurrent(); }
   TryTrade();
}
