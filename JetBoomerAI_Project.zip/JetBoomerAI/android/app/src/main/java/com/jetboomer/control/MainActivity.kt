package com.jetboomer.control

import android.app.Activity
import android.os.Bundle
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var url: EditText
    private lateinit var key: EditText
    private lateinit var status: TextView
    private lateinit var account: TextView
    private fun request(path: String, method: String = "GET", body: String? = null) {
        thread {
            try {
                val base = url.text.toString().trim().removeSuffix("/")
                val conn = URL(base + path).openConnection() as HttpURLConnection
                conn.requestMethod = method
                conn.connectTimeout = 7000; conn.readTimeout = 7000
                conn.setRequestProperty("X-API-Key", key.text.toString())
                conn.setRequestProperty("Content-Type", "application/json")
                if (body != null) { conn.doOutput = true; conn.outputStream.use { it.write(body.toByteArray()) } }
                val text = conn.inputStream.bufferedReader().readText()
                runOnUiThread { if (path == "/status") render(text) else status.text = if (conn.responseCode in 200..299) "CONNECTED" else "ERROR ${conn.responseCode}" }
            } catch (e: Exception) { runOnUiThread { status.text = "OFFLINE: ${e.message}" } }
        }
    }
    private fun render(json: String) {
        status.text = if (json.contains("\"running\":true")) "🟢 BOT RUNNING" else "🔴 BOT STOPPED"
        fun num(k:String):String = Regex("\\\"$k\\\"\\s*:\\s*(-?[0-9.]+)").find(json)?.groupValues?.get(1) ?: "--"
        fun str(k:String):String = Regex("\\\"$k\\\"\\s*:\\s*\\\"([^\\\"]*)").find(json)?.groupValues?.get(1) ?: "--"
        account.text = "Balance: ${num("balance")}\nEquity: ${num("equity")}\nDaily P/L: ${num("daily_profit")}\nOpen trades: ${num("open_trades")}\nSymbol: ${str("symbol")}\nSignal: ${str("last_signal")}"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        url=findViewById(R.id.apiUrl); key=findViewById(R.id.apiKey); status=findViewById(R.id.status); account=findViewById(R.id.account)
        findViewById<Button>(R.id.connect).setOnClickListener { request("/status") }
        findViewById<Button>(R.id.start).setOnClickListener { request("/start", "POST") }
        findViewById<Button>(R.id.stop).setOnClickListener { request("/stop", "POST") }
        findViewById<Button>(R.id.closeAll).setOnClickListener { request("/close-all", "POST") }
    }
}
