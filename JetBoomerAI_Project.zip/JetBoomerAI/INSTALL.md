# JetBoomer installation — phone-first

## 1. Build the APK from your phone

The repository contains `.github/workflows/build-apk.yml`. Upload this project to a GitHub repository from your phone, open **Actions**, run **Build Android APK**, then download the generated `JetBoomer-debug-apk` artifact. GitHub Actions performs the Android build in the cloud.

If Android Studio is available on a computer, open the `android` directory and run the normal Gradle build. Android Studio uses Gradle to compile and package APKs.

## 2. Start the API

On a VPS/server with Python 3.11+:

```bash
cd server
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8080
```

For real use, put the API behind HTTPS (for example Caddy/Nginx + a domain) and set an API key. Do not expose an unauthenticated trading API to the public internet.

## 3. Configure the EA

Copy `mt5/JetBoomerScalper.mq5` into:

`MQL5/Experts/JetBoomerScalper.mq5`

Open MetaEditor, compile with F7, attach the EA to an M1 chart, enable Algo Trading, and add the API URL to MT5's allowed WebRequest URLs.

Example input values:

- `ApiBaseUrl = https://YOUR-DOMAIN.example`
- `ApiKey = a-long-random-secret`
- `EnableLiveTrading = false` initially
- `MaxOpenTrades = 3`
- `DailyProfitTarget = 20.0`
- `DailyLossLimit = 1.0`
- `RiskPercentPerTrade = 0.5`

Test on a demo account first.

## 4. Android connection

Open JetBoomer, enter the HTTPS API URL and the same API key, then press **CONNECT**. The app polls the API for status and sends START/STOP/CLOSE-ALL commands.

## 5. VPS

Keep MT5 running on a Windows VPS or use MetaTrader's virtual hosting where compatible. The phone can be offline while the EA continues to operate on the hosted MT5 environment.

## 6. Going live

Only after demo testing:

1. Connect the desired Deriv or Weltrade MT5 account.
2. Verify the symbol names used by that broker.
3. Verify minimum lot size and contract specifications.
4. Confirm the EA can open and close a demo trade correctly.
5. Set a hard daily loss limit.
6. Only then set `EnableLiveTrading=true`.

The system is not a guaranteed-profit machine. The daily target is a stop condition, not a promise that the target will be reached.

## Official documentation

- MetaTrader algorithmic trading: https://www.metatrader5.com/en/automated-trading
- MetaTrader VPS: https://www.metatrader5.com/en/trading-platform/vps
- MQL5 EA development: https://www.metatrader5.com/en/terminal/help/algotrading/autotrading
- Android Studio: https://developer.android.com/studio
